//
//  AppDelegate.swift
//  GymApp
//
//  Created by Chander Dhiman on 01/10/22.
//

import UIKit
import IQKeyboardManagerSwift
import Firebase
import FirebaseCore
@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    class func appDelegate() -> AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        //For hiding the keyboard
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        FirebaseApp.configure()
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    func setRootHome(window:UIWindow) {
        window.rootViewController?.removeFromParent()
       
            let vcUserAuth = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "tabBarVC")
            let navUserAuth = UINavigationController(rootViewController:vcUserAuth)
            navUserAuth.navigationBar.isHidden = true
            UIView.transition(with:window, duration:0.25, options:.transitionCrossDissolve, animations: {
                window.rootViewController = navUserAuth
            }) { (completed) in}
    }
    
    func setRootLoginVC(window:UIWindow) {
        window.rootViewController?.removeFromParent()
        let vcUserAuth = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC")
        let navUserAuth = UINavigationController(rootViewController:vcUserAuth)
        navUserAuth.navigationBar.isHidden = true
        UIView.transition(with:window, duration:0.25, options:.transitionCrossDissolve, animations: {
            window.rootViewController = navUserAuth
        }) { (completed) in}
    }

    func checkUserSession(currentWindow:UIWindow) {
        if UserStoreSingleton.shared.isloggedIn == true{
            self.setRootHome(window: currentWindow)
        }else {
            self.setRootLoginVC(window: currentWindow)
        }
    }

}

