//
//  BasicTaskTVC.swift
//  Denhan
//
//  Created by Skycap on 27/04/22.
//

import UIKit
class BasicTaskTVC: UITableViewCell {
    @IBOutlet weak var lblTaskName: UILabel!
    @IBOutlet weak var lblTaskStatus: UILabel!
    @IBOutlet weak var lblTaskTime: UILabel!
    @IBOutlet weak var imgVwTaskStatus: UIImageView!
    @IBOutlet weak var acessoryImageVw: UIImageView!
    @IBOutlet weak var contentVw: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
