import UIKit
import Foundation

// MARK: - Designable Extension

extension UIView {
    
    
    
    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        get {
            return UIColor(cgColor: layer.borderColor!)
        }
        set {
            layer.borderColor = newValue?.cgColor
        }
    }
    
    @IBInspectable var cornerRadius: Double {
        get {
            return Double(self.layer.cornerRadius)
        }set {
            self.layer.cornerRadius = CGFloat(newValue)
        }
    }
    
    @IBInspectable
    /// Should the corner be as circle
    public var circleCorner: Bool {
        get {
            return min(bounds.size.height, bounds.size.width) / 2 == uiCornerRadius
        }
        set {
            uiCornerRadius = newValue ? min(bounds.size.height, bounds.size.width) / 2 : uiCornerRadius
        }
    }
    
    /// Corner radius of view; also inspectable from Storyboard.
    public var uiCornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = circleCorner ? min(bounds.size.height, bounds.size.width) / 2 : newValue
            //abs(CGFloat(Int(newValue * 100)) / 100)
        }
    }
    
    @IBInspectable
    /// Shadow color of view; also inspectable from Storyboard.
    public var shadowColor: UIColor? {
        get {
            guard let color = layer.shadowColor else {
                return nil
            }
            return UIColor(cgColor: color)
        }
        set {
            layer.shadowColor = newValue?.cgColor
        }
    }
    
    @IBInspectable
    /// Shadow offset of view; also inspectable from Storyboard.
    public var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    /// Shadow opacity of view; also inspectable from Storyboard.
    public var shadowOpacity: Double {
        get {
            return Double(layer.shadowOpacity)
        }
        set {
            layer.shadowOpacity = Float(newValue)
        }
    }
    
    @IBInspectable
    /// Shadow radius of view; also inspectable from Storyboard.
    public var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    /// Shadow path of view; also inspectable from Storyboard.
    public var shadowPath: CGPath? {
        get {
            return layer.shadowPath
        }
        set {
            layer.shadowPath = newValue
        }
    }
    
    @IBInspectable
    /// Should shadow rasterize of view; also inspectable from Storyboard.
    /// cache the rendered shadow so that it doesn't need to be redrawn
    public var shadowShouldRasterize: Bool {
        get {
            return layer.shouldRasterize
        }
        set {
            layer.shouldRasterize = newValue
        }
    }
    
    @IBInspectable
    /// Should shadow rasterize of view; also inspectable from Storyboard.
    /// cache the rendered shadow so that it doesn't need to be redrawn
    public var shadowRasterizationScale: CGFloat {
        get {
            return layer.rasterizationScale
        }
        set {
            layer.rasterizationScale = newValue
        }
    }
    
    @IBInspectable
    /// Corner radius of view; also inspectable from Storyboard.
    public var maskToBounds: Bool {
        get {
            return layer.masksToBounds
        }
        set {
            layer.masksToBounds = newValue
        }
    }
}


// MARK: - Properties

public extension UIView {
    
    /// Size of view.
    var size: CGSize {
        get {
            return self.frame.size
        }
        set {
            self.width = newValue.width
            self.height = newValue.height
        }
    }
    
    /// Width of view.
    var width: CGFloat {
        get {
            return self.frame.size.width
        }
        set {
            self.frame.size.width = newValue
        }
    }
    
    /// Height of view.
    var height: CGFloat {
        get {
            return self.frame.size.height
        }
        set {
            self.frame.size.height = newValue
        }
    }
}

// MARK: - UIView

extension UIView {
    
    func searchVisualEffectsSubview() -> UIVisualEffectView? {
        if let visualEffectView = self as? UIVisualEffectView {
            return visualEffectView
        } else {
            for subview in subviews {
                if let found = subview.searchVisualEffectsSubview() {
                    return found
                }
            }
        }
        return nil
    }
    
    /// This is the function to get subViews of a view of a particular type
    /// https://stackoverflow.com/a/45297466/5321670
    func subViews<T : UIView>(type : T.Type) -> [T]{
        var all = [T]()
        for view in self.subviews {
            if let aView = view as? T{
                all.append(aView)
            }
        }
        return all
    }
    
    
    /// This is a function to get subViews of a particular type from view recursively. It would look recursively in all subviews and return back the subviews of the type T
    /// https://stackoverflow.com/a/45297466/5321670
    func allSubViewsOf<T : UIView>(type : T.Type) -> [T]{
        var all = [T]()
        func getSubview(view: UIView) {
            if let aView = view as? T{
                all.append(aView)
            }
            guard view.subviews.count>0 else { return }
            view.subviews.forEach{ getSubview(view: $0) }
        }
        getSubview(view: self)
        return all
    }
    
    func toImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }

    var parentViewController: UIViewController? {
        var parentResponder: UIResponder? = self
        while parentResponder != nil {
            parentResponder = parentResponder!.next
            if let viewController = parentResponder as? UIViewController {
                return viewController
            }
        }
        return nil
    }
    
    func addShadow(offSet:CGSize,radius:CGFloat=3.0,color:UIColor=UIColor(white: 0.67, alpha: 0.3)) {
        self.layer.masksToBounds = false; self.clipsToBounds = false;
        self.layer.shadowOpacity = 1.0
        self.layer.shadowColor = color.cgColor
        self.layer.shadowRadius = radius
        self.layer.shadowOffset = offSet
    }
    
    func rippleEffect(darker:Bool) {
        let origin = CGPoint.init(x: self.bounds.width*0.5, y: self.bounds.height*0.5)
//        let color = (darker == true) ? self.backgroundColor?.darker(by:25) : self.backgroundColor?.lighter(by: 25)
        let duration = 0.33
        let fadeDelay = 0.75*duration
        let radius = (self.bounds.size.width > self.bounds.size.height) ? self.bounds.size.width : self.bounds.size.height
        
//        rippleEffect(origin: origin, color: color!, duration: duration, radius: radius, fadeDelay: fadeDelay)
    }

    func springPopAnimation() {
        self.transform = CGAffineTransform(scaleX: 0.6, y: 0.6)
        UIView.animate(withDuration: 2.0,
                       delay: 0,
                       usingSpringWithDamping: CGFloat(0.20),
                       initialSpringVelocity: CGFloat(6.0),
                       options: UIView.AnimationOptions.allowUserInteraction,
                       animations: {
                        self.transform = CGAffineTransform.identity
                       },
                       completion: { Void in()  }
        )
    }
    
    func shakeAnimation() {
        UIView.animate(withDuration:0.2, delay:0, usingSpringWithDamping: 0.5, initialSpringVelocity:1.0, options:[.repeat,.allowUserInteraction,.autoreverse], animations: {
            UIView.animate(withDuration:0.1, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [.repeat,.allowUserInteraction,.autoreverse], animations: {
                self.transform = CGAffineTransform.init(rotationAngle:0.01)
            }, completion: { (completed1) in
            })
            UIView.animate(withDuration:0.1, delay: 0.1, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [.repeat,.allowUserInteraction,.autoreverse], animations: {
                self.transform = CGAffineTransform.init(rotationAngle:(-0.01))
            }, completion: { (completed2) in
            })
        }) { (completed) in}
    }
    
    func pendulamAnimation(offSetX:CGFloat) {
        UIView.animate(withDuration:0.1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 0.9, options:.transitionCrossDissolve, animations: {
            self.transform = CGAffineTransform.init(translationX: offSetX, y:0)
        }, completion: { (completed) in
            UIView.animate(withDuration:0.1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 0.9, options:.transitionCrossDissolve, animations: {
                self.transform = CGAffineTransform.init(translationX: offSetX*(-1), y:0)
            }, completion: { (completed1) in
                UIView.animate(withDuration:0.1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 0.9, options:.transitionCrossDissolve, animations: {
                    self.transform = CGAffineTransform.init(translationX: offSetX*0.5, y:0)
                }, completion: { (completed2) in
                    UIView.animate(withDuration:0.1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 0.9, options:.transitionCrossDissolve, animations: {
                        self.transform = CGAffineTransform.init(translationX: offSetX*(-0.5), y:0)
                    }, completion: { (completed3) in
                        UIView.animate(withDuration:0.1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 0.9, options:.transitionCrossDissolve, animations: {
                            self.transform = CGAffineTransform.identity
                        }, completion: { (completed4) in
                        })
                    })
                })
            })
        })
    }
    
    func blinkAnimation() {
        let flash = CABasicAnimation(keyPath: "opacity")
        flash.duration = 0.2
        flash.fromValue = 1
        flash.toValue = 0.0
        flash.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        flash.autoreverses = true
        flash.repeatCount = 4
        layer.add(flash, forKey: nil)
    }
    
    func fadeIn(duration: TimeInterval = 0.4, delay: TimeInterval = 0.0, completion: @escaping ((Bool) -> Void) = {(finished: Bool) -> Void in }) {
        self.alpha = 0.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.transitionCrossDissolve, animations: {
            self.isHidden = false
            self.alpha = 1.0
        }, completion: completion)
    }
    
    func fadeOut(duration: TimeInterval = 0.5, delay: TimeInterval = 0.0, completion: @escaping (Bool) -> Void = {(finished: Bool) -> Void in }) {
        self.alpha = 1.0
        
        UIView.animate(withDuration: duration, delay: delay, options: UIView.AnimationOptions.transitionCrossDissolve, animations: {
            self.alpha = 0.0
        }) { (completed) in
            self.isHidden = true
            completion(true)
        }
    }
    
    @discardableResult func showLoadingIndicator(superViewFrame:Bool=false) -> Bool {
        if let _:ProgressIndicator = self.viewWithTag(19518) as? ProgressIndicator {
            return false
        }
        else {
            ProgressIndicator.shared().show(at: self,superViewFrame:superViewFrame )
            return true
        }
    }
    
    func hideLoadingIndicator () {
        if let indicator:ProgressIndicator = self.viewWithTag(19518) as? ProgressIndicator {
            indicator.hide(at: self)
            self.parentViewController?.presentedViewController?.view.isUserInteractionEnabled = true
        }
    }
}
@IBDesignable
public class GradientView: UIView {
    @IBInspectable var startColor:   UIColor = .black { didSet { updateColors() }}
    @IBInspectable var endColor:     UIColor = .white { didSet { updateColors() }}
    @IBInspectable var startLocation: Double =   0.05 { didSet { updateLocations() }}
    @IBInspectable var endLocation:   Double =   0.95 { didSet { updateLocations() }}
    @IBInspectable var horizontalMode:  Bool =  false { didSet { updatePoints() }}
    @IBInspectable var diagonalMode:    Bool =  false { didSet { updatePoints() }}

    override public class var layerClass: AnyClass { CAGradientLayer.self }

    var gradientLayer: CAGradientLayer { layer as! CAGradientLayer }

    func updatePoints() {
        if horizontalMode {
            gradientLayer.startPoint = diagonalMode ? .init(x: 1, y: 0) : .init(x: 0, y: 0.5)
            gradientLayer.endPoint   = diagonalMode ? .init(x: 0, y: 1) : .init(x: 1, y: 0.5)
        } else {
            gradientLayer.startPoint = diagonalMode ? .init(x: 0, y: 0) : .init(x: 0.5, y: 0)
            gradientLayer.endPoint   = diagonalMode ? .init(x: 1, y: 1) : .init(x: 0.5, y: 1)
        }
    }
    func updateLocations() {
        gradientLayer.locations = [startLocation as NSNumber, endLocation as NSNumber]
    }
    func updateColors() {
        gradientLayer.colors = [startColor.cgColor, endColor.cgColor]
    }
    override public func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        updatePoints()
        updateLocations()
        updateColors()
    }
}
@IBDesignable class PaddingLabel: UILabel {

    @IBInspectable var topInset: CGFloat = 5.0
    @IBInspectable var bottomInset: CGFloat = 5.0
    @IBInspectable var leftInset: CGFloat = 7.0
    @IBInspectable var rightInset: CGFloat = 7.0

    override func drawText(in rect: CGRect) {
        let insets = UIEdgeInsets(top: topInset, left: leftInset, bottom: bottomInset, right: rightInset)
        super.drawText(in: rect.inset(by: insets))
    }

    override var intrinsicContentSize: CGSize {
        let size = super.intrinsicContentSize
        return CGSize(width: size.width + leftInset + rightInset,
                      height: size.height + topInset + bottomInset)
    }

    override var bounds: CGRect {
        didSet {
            // ensures this works within stack views if multi-line
            preferredMaxLayoutWidth = bounds.width - (leftInset + rightInset)
        }
    }
}


@IBDesignable
class TwoCornerRoundView : UIView
{
  @IBInspectable var roundValue  : CGFloat = 0
  override func layoutSubviews()
  {
    super.layoutSubviews()
    //calculate by percentage
    let makeRoundCorner = (roundValue * layer.frame.width)/100
    let maskLayer    = CAShapeLayer()
    var roundedCorners = UIRectCorner()
    roundedCorners.insert(.topRight)
    roundedCorners.insert(.topLeft)
    maskLayer.path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: roundedCorners, cornerRadii: CGSize(width: makeRoundCorner, height: makeRoundCorner)).cgPath
    layer.mask = maskLayer
  }
}

@IBDesignable
class TwoCornerRoundViewScroll : UIScrollView
{
  @IBInspectable var roundValue  : CGFloat = 0
  override func layoutSubviews()
  {
    super.layoutSubviews()
    //calculate by percentage
    let makeRoundCorner = (roundValue * layer.frame.width)/100
    let maskLayer    = CAShapeLayer()
    var roundedCorners = UIRectCorner()
    roundedCorners.insert(.topRight)
    roundedCorners.insert(.topLeft)
    maskLayer.path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: roundedCorners, cornerRadii: CGSize(width: makeRoundCorner, height: makeRoundCorner)).cgPath
    layer.mask = maskLayer
  }
}
