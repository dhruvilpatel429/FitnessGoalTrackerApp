//
//  ProgressIndicator.swift
//
//  Created by Skycap on 10/9/17.
//  Copyright © 2017 Skycap. All rights reserved.
//

import UIKit
class ProgressIndicator: UIView {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var useSuperViewFrame = false
    class func initWith(frame:CGRect) -> ProgressIndicator {
        let indicator  = Bundle.main.loadNibNamed("ProgressIndicator", owner:self, options:nil)?.first as! ProgressIndicator
        indicator.frame = frame
        return indicator
    }
    
    class func shared() -> ProgressIndicator {
        return ProgressIndicator.initWith(frame:UIScreen.main.bounds)
    }
    
    func show(at superView:UIView, superViewFrame:Bool=false) {
        useSuperViewFrame = superViewFrame
        if superViewFrame == true {
            self.frame = superView.bounds
        }
        else {
            let height = CGFloat(210)
            let posX = (superView.frame.size.width-height)*0.5
            let posY = (superView.frame.size.height-height)*0.5
            self.frame = CGRect.init(x: posX, y: posY, width: height, height: height)
        }
        self.tag = 19518
        addTo(superView: superView)
        activityIndicator.transform = CGAffineTransform(scaleX: 1.25, y: 1.25)
        activityIndicator.startAnimating()
    }
   
    func hide(at superView:UIView) {
        self.activityIndicator.stopAnimating()
        self.removeFromSuperview()
        superView.isUserInteractionEnabled = true
    }
    
    func addTo(superView:UIView) {
        superView.addSubview(self)
        superView.isUserInteractionEnabled = false
        self.translatesAutoresizingMaskIntoConstraints = false
        superview?.addConstraints(
            [NSLayoutConstraint(item:superView, attribute:.centerX, relatedBy:.equal, toItem:self, attribute:.centerX, multiplier: 1.0, constant:0),
             NSLayoutConstraint(item:superView, attribute:.centerY, relatedBy:.equal, toItem:self, attribute:.centerY, multiplier: 1.0, constant:0)]
        )
    }
}
