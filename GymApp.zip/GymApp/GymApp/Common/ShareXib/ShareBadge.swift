//
//  ShareBadge.swift
//  GymApp
//
//  Created by Chander Dhiman on 20/10/22.
//

import UIKit
import FacebookShare
protocol ShareBadgeProtocol : AnyObject {
    func cancel()
}

class ShareBadge: UIView {
    @IBOutlet weak var imgVwBadge: UIImageView!
    @IBOutlet weak var lblStreak: UILabel!
    override func awakeFromNib() {
    }
    
    @IBAction func actionBtnBack(_ sender: Any) {
        self.removeFromSuperview()
    }
    
}
