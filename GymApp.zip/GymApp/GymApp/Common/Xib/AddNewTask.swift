//
//  AddNewTask.swift
//  Denhan
//
//  Created by Skycap on 02/05/22.
//

import UIKit

protocol AddTaskDelegate : AnyObject {
    func cancelButtonClicked()
    func saveButtonClicked(time:String)
}

class AddNewTask: UIView {
    weak var delegate : AddTaskDelegate?
    @IBOutlet weak var datePicker: UIDatePicker!
    var timeStr = String()
    override func awakeFromNib() {
        self.backgroundColor = .clear
    }
    
    @IBAction func actionBtnSave(_ sender: Any) {
        delegate?.saveButtonClicked(time: self.timeStr)
        self.removeFromSuperview()
    }
    
    @IBAction func actionBtnCancel(_ sender: Any) {
        delegate?.cancelButtonClicked()
        self.removeFromSuperview()
    }
    
    @IBAction func datePickerChanged(_ sender: Any) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"
        let string = dateFormatter.string(from: datePicker.date)
        self.timeStr = string
    }
    
}
