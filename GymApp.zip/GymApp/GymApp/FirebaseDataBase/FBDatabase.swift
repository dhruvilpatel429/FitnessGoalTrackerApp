//
//  FBDatabase.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import Foundation
import Firebase
class FBDatabase {
    typealias callback = ((_ status : Bool, _ error : String, _ result : AuthDataResult?) -> Void)
    static let shared = FBDatabase()
    func authFBUser(email:String?,password:String?, result : @escaping (callback)) {
        guard let userEmail = email, let userPassword = password else { return }

        Auth.auth().createUser(withEmail: userEmail, password: userPassword) { (dataResult, error) in
            if let error = error{
                result(false, error.localizedDescription , dataResult)
            }else {
                result(true, "", dataResult)
            }
        }
    }
    
    func signInFBUser(email:String?,password:String?, result : @escaping (callback)) {
        guard let userEmail = email, let userPassword = password else { return }
        
        Auth.auth().signIn(withEmail: userEmail, password: userPassword) { (dataResult, error) in
            if let error = error {
                result(false, error.localizedDescription , dataResult)
            }else {
                result(true, "", dataResult)
            }
        }
    }
    
}
