//
//  Constant.swift
//  GymApp
//
//  Created by Chander Dhiman on 12/10/22.
//

import Foundation
enum TaskStatus : Int {
    case notStarted = 0
    case inProgress = 1
    case completed = 2
}

//MARK: - Date Extension 
extension Date {
    static func getDates(forLastNDays nDays: Int) -> [String] {
        let cal = NSCalendar.current
        // start with today
        var date = cal.startOfDay(for: Date())

        var arrDates = [String]()

        for _ in 1 ... nDays {
            // move back in time by one day:
            date = cal.date(byAdding: Calendar.Component.day, value: -1, to: date)!

            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy"
            let dateString = dateFormatter.string(from: date)
            arrDates.append(dateString)
        }
        return arrDates.reversed()
    }
}
