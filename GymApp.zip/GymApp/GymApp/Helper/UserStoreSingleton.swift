//
//  UserStoreSingleton.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import Foundation

class UserStoreSingleton {
    static let shared = UserStoreSingleton()
    var isloggedIn : Bool! {
        get {
            return UserDefaults().object(forKey: "isloggedIn") as? Bool
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "isloggedIn")
        }
    }
    
    
    var uid : String! {
        get {
            return UserDefaults().object(forKey: "uid") as? String
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "uid")
        }
    }
    
    var streak : Int! {
        get {
            return UserDefaults().object(forKey: "streak") as? Int
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "streak")
        }
    }
    
    var userId : String! {
        get {
            return UserDefaults().object(forKey: "userId") as? String
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "userId")
        }
    }
    
    var personId : String! {
        get {
            return UserDefaults().object(forKey: "personId") as? String
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "personId")
        }
    }
  
}


