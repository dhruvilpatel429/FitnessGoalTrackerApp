//
//  AddNewVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 09/10/22.
//

import UIKit
import FirebaseCore
import FirebaseFirestore
import Firebase
class AddNewVC: UIViewController, AddTaskDelegate {
    
    @IBOutlet weak var txtVwDescription: UITextView!
    @IBOutlet weak var txtFldGoalName: UITextField!
    @IBOutlet weak var txtFldTime: UITextField!
    @IBOutlet weak var txtFldDate: UITextField!
    @IBOutlet weak var switchReminder: UISwitch!
    
    let db = Firestore.firestore() // intilaize database
    var timeStr = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtFldDate.setDatePickerAsInputViewFor(mode: "date", target: self, selector: #selector(dateSelected))
        self.txtFldTime.setDatePickerAsInputViewFor(mode: "time", target: self, selector: #selector(timeSelected))
        
       }
    
    //MARK: - ActionSave
    @IBAction func actionBtnSave(_ sender: Any) {
        if txtFldGoalName.text!.isEmpty == true{
            showAlert(title: "Alert", message: "Enter your goal first!")
            return
        }
        
        if txtFldTime.text!.isEmpty == true { showAlert(title: "Alert", message: "Enter your time first!")
            return
        }
        
        if txtFldDate.text!.isEmpty == true { showAlert(title: "Alert", message: "Enter your Date first!")
            return
        }
        
        
        self.view.showLoadingIndicator()
        let userID = Auth.auth().currentUser?.uid ?? ""
        let udid = UUID().uuidString ?? ""
        let infoDict : [String:Any] = ["goalName":txtFldGoalName.text!,"date":txtFldDate.text!,"time":txtFldTime.text!,"isReminder": switchReminder.isOn,"uid":userID,"reminderTime":timeStr,"description":txtVwDescription.text!,"id":udid,"status":TaskStatus.notStarted.rawValue]
        
        let ref = db.collection("events")
        let data = ref.document("\(udid)").setData(infoDict) { err in
            
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                self.clearDataOnSaveScreen()
                self.showAlert(title: "Success", message: "Your Event has been saved successfully")
            }
            self.view.hideLoadingIndicator()
        }
    }
    
    //MARK: - Clear Data on Save Screen
    func clearDataOnSaveScreen(){
        self.txtFldGoalName.text = ""
        self.txtVwDescription.text = ""
        self.txtFldDate.text = ""
        self.txtFldTime.text = ""
    }
    
    @IBAction func actionBtnReminder(_ sender: Any) {
        let infoWindow = Bundle.main.loadNibNamed("AddNewTask", owner: AddNewVC.self, options: nil)![0] as! AddNewTask
        infoWindow.delegate = self
        infoWindow.frame = self.view.bounds
        if switchReminder.isOn {
            self.txtFldTime.resignFirstResponder()
            self.txtFldDate.resignFirstResponder()
            self.txtFldGoalName.resignFirstResponder()
            self.view.addSubview(infoWindow)
        }
    }
    
    //MARK: - Date Selected
    @objc func dateSelected() {
        if let datePicker = self.txtFldDate.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy"
            self.txtFldDate.text = dateFormatter.string(from: datePicker.date)
        }
        self.txtFldDate.resignFirstResponder()
    }
    
    @objc func timeSelected() {
        if let datePicker = self.txtFldTime.inputView as? UIDatePicker {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "hh:mm a"
            self.txtFldTime.text = dateFormatter.string(from: datePicker.date)
        }
        self.txtFldTime.resignFirstResponder()
    }
    
    //MARK: - Protocols for passing the data
    func cancelButtonClicked() {
        self.switchReminder.setOn(false, animated: true)
    }
    
    func saveButtonClicked(time: String) {
        self.timeStr = time
        self.switchReminder.setOn(true, animated: true)
    }
    
    func showAlert(title:String,message:String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default))
        self.present(alert, animated: true)
        
    }
    
    func showActionAlert(title:String,message:String){
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
            UIAlertAction in
            
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) {
            UIAlertAction in
        }
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
}

//MARK: - Events Date
class EventDates {
    
    var goalName : String?
    var date : String
    var time : String?
    var isReminder : Bool?
    var userId : String?
    var reminderTime : String?
    var description : String?
    var status : Int?
    var id : String?
    init(goalName: String? = nil, date: String, time: String? = nil, isReminder: Bool? = nil,userId: String? = nil,reminderTime: String? = nil,description: String? = nil,id:String? = nil,status: Int? = nil) {
        self.goalName = goalName
        self.date = date
        self.time = time
        self.isReminder = isReminder
        self.userId = userId
        self.reminderTime = reminderTime
        self.description = description
        self.id = id
        self.status = status
    }
}
