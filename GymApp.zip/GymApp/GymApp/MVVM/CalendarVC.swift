//
//  CalendarVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import UIKit
import FSCalendar
import Firebase
import FirebaseDatabase
import FirebaseStorage
class CalendarVC: UIViewController {

    @IBOutlet weak var calendarVw: FSCalendar!
    @IBOutlet weak var tblVwEvents: UITableView!
    @IBOutlet weak var lblNoData: UILabel!
    var dateformatter = DateFormatter()
    var dates = [EventDates]()
    var selectedDates = [EventDates]()
    var ref: DatabaseReference! //reference of database
    let db = Firestore.firestore() // intilaize database
    var lastSelectedDate = String()
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.getAllCalendarDetails()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateformatter.dateFormat = "dd-MM-yyyy"
        self.tblVwEvents.estimatedRowHeight = 100
        calendarVw.placeholderType =  FSCalendarPlaceholderType.none
        calendarVw.appearance.headerMinimumDissolvedAlpha = 0.0
    }
    
    func getAllCalendarDetails(){
        self.selectedDates.removeAll()
        self.dates.removeAll()
        self.view.showLoadingIndicator()
        let userID = Auth.auth().currentUser?.uid ?? ""
        let eventsRef = db.collection("events")
        let query = eventsRef.whereField("uid", isEqualTo: userID).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    let documentData = document.data()
                    let obj = EventDates(goalName: documentData["goalName"] as? String ?? "", date: documentData["date"] as? String ?? "",time: documentData["time"] as? String ?? "",isReminder: documentData["isReminder"] as? Bool ?? false,userId: documentData["uid"] as? String ?? "",reminderTime: documentData["reminderTime"] as? String ?? "",description: documentData["description"] as? String ?? "",id: documentData["id"] as? String ?? "", status: documentData["status"] as? Int ?? 0)
                    self.dates.append(obj)
                }
                self.view.hideLoadingIndicator()
                self.calendarVw.delegate = self
                self.calendarVw.dataSource = self
                self.calendarVw.reloadData()
             }
         }
    }
}
extension CalendarVC : FSCalendarDelegate, FSCalendarDataSource {
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let date = dateFormatter.string(from: date)
        let index = dates.firstIndex { $0.date == date }
        if index != nil {
            return 1
        }
        return 0
    }
    
    func calendar(_ calendar: FSCalendar, willDisplay cell: FSCalendarCell, for date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        let date = dateformatter.string(from: date)
        let currentDate = dateformatter.string(from: Date())
        if date == currentDate {
            let filteredObject = self.dates.filter { $0.date == date }
            if filteredObject.count == 0 {
                self.lblNoData.isHidden = false
            }else {
                self.lblNoData.isHidden = true
            }
            self.selectedDates = filteredObject
            self.tblVwEvents.reloadData()
        }else if date == lastSelectedDate {
            let filteredObject = self.dates.filter { $0.date == date }
            if filteredObject.count == 0 {
                self.lblNoData.isHidden = false
            }else {
                self.lblNoData.isHidden = true
            }
            self.selectedDates = filteredObject
            self.tblVwEvents.reloadData()
        }
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let date = dateformatter.string(from: date)
        self.lastSelectedDate = date
        let filteredObject = self.dates.filter { $0.date == date }
        if filteredObject.count == 0 {
            self.lblNoData.isHidden = false
        }else {
            self.lblNoData.isHidden = true
        }
        self.selectedDates = filteredObject
        self.tblVwEvents.reloadData()
    }
}

extension CalendarVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedDates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tblVwEvents.dequeueReusableCell(withIdentifier: "BasicTaskCell", for: indexPath) as! BasicTaskTVC
        cell.lblTaskName.text = self.selectedDates[indexPath.row].goalName
        cell.lblTaskTime.text = self.selectedDates[indexPath.row].time
        cell.lblTaskStatus.text = "Not Started"
        
        let status = self.selectedDates[indexPath.row].status
        switch status {
        case 0:
            cell.lblTaskStatus.text = "Not Started"
            cell.imgVwTaskStatus.image = UIImage(named: "new")
        case 1:
            cell.lblTaskStatus.text = "In Progress"
            cell.imgVwTaskStatus.image = UIImage(named: "progress")
        case 2:
            cell.lblTaskStatus.text = "Completed"
            cell.imgVwTaskStatus.image = UIImage(named: "completed")
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "TaskDetailVC") as! TaskDetailVC
        vc.objEvent = selectedDates[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
