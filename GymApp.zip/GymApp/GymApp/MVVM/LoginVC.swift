//
//  LoginVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 01/10/22.
//

import UIKit
import Firebase
class LoginVC: UIViewController {

    @IBOutlet weak var emailVw: UIView!
    @IBOutlet weak var passwordVw: UIView!
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //add shadow
    func addShadow(){
        
    }
    
    //MARK: - Action Buttons
    @IBAction func actionBtnSignIn(_ sender: Any) {
        self.view.showLoadingIndicator()
        LoginVM.shared.onclickAuthUser(email: txtFldEmail.text!, password: txtFldPassword.text!) { status, error, result in
            if (status) {
                self.view.hideLoadingIndicator()
                let tabBarVC = self.storyboard?.instantiateViewController(withIdentifier: "tabBarVC") as! tabBarVC
                self.navigationController?.pushViewController(tabBarVC, animated: true)
                UserStoreSingleton.shared.uid = result?.user.uid
                UserStoreSingleton.shared.isloggedIn = true
            }else {
                self.view.hideLoadingIndicator()
              debugPrint("error",error)
            }
        }
    }
    
    @IBAction func actionBtnSignUp(_ sender: Any) {
        let signVC = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(signVC, animated: true)
    }
    
}
