//
//  Copyright (c) 2015 Google Inc.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

import UIKit
import Firebase
class User: NSObject {
  var username: String

  init(username: String) {
    self.username = username
  }

  override convenience init() {
    self.init(username: "")
  }
}



//MARK: -
//struct studentData: Codable {
//    var user: Periods
//
//    enum CodingKeys: String, CodingKey {
//        case user = "posts"
//    }
//}

//// MARK: - User
//struct Users: Codable {
//    var detail: Periods
//
//    enum CodingKeys: String, CodingKey {
//        case detail = "Detail"
//    }
//}
//// MARK: - Detail  ,
//public struct Periods: Codable {
//    public var innerArray: [String: Detail]
//    public var valueArray: [Detail]
//
//    public struct Detail: Codable {
//        var author : String?
//        var body : String?
//        var title : String?
//        var uid : String?
//    }
//
//    private struct CustomCodingKeys: CodingKey {
//        var stringValue: String
//        init?(stringValue: String) {
//            self.stringValue = stringValue
//        }
//        var intValue: Int?
//        init?(intValue: Int) {
//            return nil
//        }
//    }
//    public init(from decoder: Decoder) throws {
//        let container = try decoder.container(keyedBy: CustomCodingKeys.self)
//
//        self.innerArray = [String: Detail]()
//        self.valueArray = [Detail]()
//        for key in container.allKeys {
//            var value = try container.decode(Detail.self, forKey: CustomCodingKeys(stringValue: key.stringValue)!)
//            value.fireBaseKey = key.stringValue
//            self.innerArray[key.stringValue] = value
//            self.valueArray.append(value)
//        }
//        self.valueArray = self.valueArray.sorted(by: {$0.name ?? "" < $1.name ?? "" })
//    }
//}


