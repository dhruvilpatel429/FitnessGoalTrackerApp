//
//  ProfileVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseCore
import SDWebImage
class ProfileVC: UIViewController {
   
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblDateOfBirth: UILabel!
    @IBOutlet weak var lblStreaj: UILabel!
    @IBOutlet weak var lblBadge: UILabel!
    
    @IBOutlet weak var imgVwProfile: UIImageView!
    var ref: DatabaseReference! //reference of database
    let db = Firestore.firestore() // intilaize database
    var userData : UserData?
    override func viewDidLoad() {
        super.viewDidLoad()
        getAllUserInfoDetails()
    }
    
    func getAllUserInfoDetails(){
        self.view.showLoadingIndicator()
        let userID = Auth.auth().currentUser?.uid ?? ""
        let eventsRef = db.collection("users")
        let query = eventsRef.whereField("uid", isEqualTo: userID).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    let documentData = document.data()
                    let info = UserData(badge: documentData["badge"] as? String ?? "",email: documentData["email"] as? String ?? "" ,firstName: documentData["firstName"] as? String ?? "" ,lastName: documentData["lastName"] as? String ?? "" ,steak: documentData["streak"] as? Int ?? 0 ,uid: documentData["uid"] as? String ?? "",profilePicUrl: documentData["profilePicUrl"] as? String ?? "")
                    self.userData = info
                    self.setUpUI()
                }
                
                self.view.hideLoadingIndicator()
             }
         }
    }
    
    func setUpUI(){
        self.lblName.text = "\(self.userData?.firstName ?? "") \(self.userData?.lastName ?? "")"
        self.lblBadge.text = self.userData?.badge ?? "Starter"
        self.lblEmail.text = self.userData?.email ?? ""
        self.lblStreaj.text = "\(self.userData?.steak ?? 0)"
        if let url = URL(string: self.userData?.profilePicUrl ?? "") {
            self.imgVwProfile.sd_setImage(with: url)
        }
    }

    @IBAction func actionBtnSignOut(_ sender: Any) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
        
        UserStoreSingleton.shared.isloggedIn = false
        guard let window = self.view.window else {return}
        AppDelegate.appDelegate().checkUserSession(currentWindow:window)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
}

class UserData {
    let badge : String?
    let email : String?
    let firstName : String?
    let lastName : String?
    let steak : Int?
    let uid : String?
    let profilePicUrl : String?
    
    init(badge: String? = nil, email: String? = nil, firstName: String? = nil, lastName: String? = nil, steak: Int? = nil, uid: String? = nil, profilePicUrl: String? = nil) {
        self.badge = badge
        self.email = email
        self.firstName = firstName
        self.lastName = lastName
        self.steak = steak
        self.uid = uid
        self.profilePicUrl = profilePicUrl
    }
}
