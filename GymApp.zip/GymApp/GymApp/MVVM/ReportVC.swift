//
//  ReportVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import UIKit
import Charts
import Firebase
import ALProgressView
class ReportVC: UIViewController, ChartViewDelegate {
    @IBOutlet weak var progressBar: ALProgressRing!
    @IBOutlet weak var chartVw: BarChartView!
    @IBOutlet weak var lblProgressBar: UILabel!
    
    var dateformatter = DateFormatter()
    var dates = [String]()
    let db = Firestore.firestore()
    var lastDates = [String]()
    var XDates = [String]()
    var barDataEntries = [BarChartDataEntry(x: 0, y: 0)]
    var totalTask = Int()
    var completedTask = Int()
    
    weak var axisFormatDelegate: AxisValueFormatter?
    override func viewDidLoad() {
        super.viewDidLoad()
        dateformatter.dateFormat = "dd-MM-yyyy"
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        axisFormatDelegate = self
        let dates = Date.getDates(forLastNDays: 7)
        self.lastDates = dates
        self.getTodayTask()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.getAllDatesDetails()
        }
    }
    
    func getTodayTask(){
        self.completedTask = 0
        self.totalTask = 0
        let currentDate = dateformatter.string(from: Date())
        let userID = Auth.auth().currentUser?.uid ?? ""
        let eventsRef = db.collection("events")
        let query = eventsRef.whereField("date", isEqualTo: currentDate).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    let documentData = document.data()
                    let obj = EventDates(goalName: documentData["goalName"] as? String ?? "", date: documentData["date"] as? String ?? "",time: documentData["time"] as? String ?? "",isReminder: documentData["isReminder"] as? Bool ?? false,userId: documentData["uid"] as? String ?? "",reminderTime: documentData["reminderTime"] as? String ?? "",description: documentData["description"] as? String ?? "",id: documentData["id"] as? String ?? "", status: documentData["status"] as? Int ?? 0)
                     if obj.status == 2 {
                        self.completedTask += 1
                    }
                }
                self.totalTask = querySnapshot?.count ?? 0
                
                self.lblProgressBar.text = "\(self.completedTask)" + "/" + "\(self.totalTask)"
                
                if self.completedTask != 0 {
                    let value = 1 / self.completedTask
                    let percentage = Double(value) / Double(self.totalTask)
                    self.progressBar.setProgress(Float(percentage), animated: true)
                }else{
                    self.progressBar.setProgress(Float(0.0), animated: true)
                }
             }
         }
    }

    func getAllDatesDetails(){
        self.dates.removeAll()
        self.view.showLoadingIndicator()
        let userID = Auth.auth().currentUser?.uid ?? ""
        let eventsRef = db.collection("events")
        let query = eventsRef.whereField("uid", isEqualTo: userID).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    let documentData = document.data()
                    let date = documentData["date"] as? String ?? ""
                    if self.lastDates.contains(date) {
                        self.dates.append(date)
                    }
                }
                self.getData()
                self.view.hideLoadingIndicator()
             }
         }
    }
    
    func getData(){
        self.barDataEntries.removeAll()
        self.XDates.removeAll()
        var counts: [String: Int] = [:]
        for item in dates {
            counts[item] = (counts[item] ?? 0) + 1
        }

        print(counts)  // "[BAR: 1, FOOBAR: 1, FOO: 2]"
        var x = 0
        for (key, value) in counts {
           
            let barDataEntry = BarChartDataEntry(x: Double(x), y: Double(value))
            self.barDataEntries.append(barDataEntry)
            x += 1
            self.XDates.append(key)
            print("\(key) occurs \(value) time(s)")
        }
        self.XDates = XDates.reversed()
        self.setup(barLineChartView: chartVw)
    }
    
    
    
    func setup(barLineChartView chartView: BarChartView) {
        chartView.chartDescription.enabled = false
        
        chartView.dragEnabled = true
        chartView.setScaleEnabled(true)
        chartView.pinchZoomEnabled = false
      //  chartView.maxVisibleCount = 7
        chartView.delegate = self
        
        let set = BarChartDataSet(entries: barDataEntries)
        
        set.colors = ChartColorTemplates.joyful()
        let data = BarChartData(dataSet: set)
        let xaxis = chartView.xAxis
        xaxis.labelPosition = .bottom
        xaxis.labelCount = self.barDataEntries.count - 1
        xaxis.valueFormatter = axisFormatDelegate
        //xaxis.setLabelCount(self.barDataEntries.count - 1, force: true)
       // xaxis.avoidFirstLastClippingEnabled = false
       // xaxis.forceLabelsEnabled = true
        chartView.data = data
        chartView.animate(xAxisDuration: 1)
        chartView.animate(yAxisDuration: 1)
        
    }
    
}

extension ReportVC: AxisValueFormatter {
  
  func stringForValue(_ value: Double, axis: AxisBase?) -> String {
 debugPrint("value",value)
      
      if XDates.count > 0 {
          if value == 0.0 {
              return XDates[0]
          }else if value == 1.0 {
              return XDates[1]
          }else if value == 2.0 {
              return XDates[2]
          }else if value == 3.0 {
              return XDates[3]
          }else if value == 4.0 {
              return XDates[4]
          }else if value == 5.0 {
              return XDates[5]
          }else if value == 6.0 {
              return XDates[6]
          }else {
              return ""
          }
      }
      return ""
//    let dateFormatter = DateFormatter()
//    dateFormatter.dateFormat = "dd-MM-yyyy"
//    return "15-10-2022"
  }
  
}

