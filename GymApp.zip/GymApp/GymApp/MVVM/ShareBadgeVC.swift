//  ShareBadgeVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 25/10/22.

import UIKit
import FacebookShare
class ShareBadgeVC: UIViewController {
    @IBOutlet weak var imgVwLevel: UIImageView!
    var imgStr = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imgVwLevel.image = UIImage(named: imgStr)
    }
    
    @IBAction func actionBtnFacebook(_ sender: Any) {
        debugPrint("Action Button Facebook")
    }
    
}
