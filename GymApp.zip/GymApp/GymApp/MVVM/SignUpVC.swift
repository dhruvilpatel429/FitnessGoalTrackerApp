//
//  SignUpVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 01/10/22.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseStorage
import FirebaseFirestore
import AVFoundation
class SignUpVC: UIViewController,UINavigationControllerDelegate {
    
    @IBOutlet weak var imgVwProfilePicture: UIImageView!
    @IBOutlet weak var txtFldFirstName: UITextField!
    @IBOutlet weak var txtFldLastName: UITextField!
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtFldPassword: UITextField!
    @IBOutlet weak var txtFldReEnterPassword: UITextField!
    let db = Firestore.firestore()
    var ref: DatabaseReference!
     // Storage Reference
    var imagePicker = UIImagePickerController()
    
    //MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func actionBtnImgVw(_ sender: Any) {
       // self.checkCameraAccess()
        
        let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
                self.openCamera()
            }))
            
            alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
                self.openGallary()
            }))
            
            alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(alert, animated: true)
        
    }
    
    @IBAction func actionBtnSignUp(_ sender: Any) {
        self.authUser(email: txtFldEmail.text!, password: txtFldPassword.text!)
    }
    
    @IBAction func actionBtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - AuthUserWithFirebase
    func authUser(email:String, password:String) {
        self.view.showLoadingIndicator()
        SignInVM.shared.onclickSignUpUser(email: email, password: password) { status, error, result in
            if (status) {
                self.view.hideLoadingIndicator()
              //self.storeUserDataInDatabase()
                self.uploadProfilePic()
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "tabBarVC") as! tabBarVC
                self.navigationController?.pushViewController(vc, animated: true)
                UserStoreSingleton.shared.uid = result?.user.uid
            }else{
                self.view.hideLoadingIndicator()
                debugPrint("error",error)
            }
        }
    }
    
    func uploadProfilePic(){
      //  let storageRef = Storage.storage().reference()
        let path = UUID().uuidString
       // let imageRef = storageRef.child("User/Detail").child("\(path).png")
        let storageRef = Storage.storage().reference().child("User/Detail").child("\(Date().timeIntervalSince1970).png")
        guard let imgData = self.imgVwProfilePicture.image!.jpegData(compressionQuality: 0.2) else { return}
        let metaData = StorageMetadata()
        let uploadTask = storageRef.putData(imgData,metadata: metaData) { (metadata, error) in
            storageRef.downloadURL { (url, error) in
                guard let urlString = url?.absoluteString else { return }
                self.storeUserDataInDatabase(profilePic: urlString)
            }
        }
    }
    
    //MARK: - StoreUserDetailsInDatabase
    func storeUserDataInDatabase(profilePic:String){
        let userID = Auth.auth().currentUser?.uid ?? ""
        var ref : DocumentReference!
        let infoDict : [String:Any] = ["firstName":txtFldFirstName.text!,"lastName":txtFldLastName.text!,"uid":userID,"streak": 0,"email":txtFldEmail.text!,"badge":"Apprentice","docId":"","lastUpdatedStreak":"","profilePicUrl":profilePic]
        
        ref = db.collection("users").addDocument(data: infoDict) { err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                self.updateDocumentKey(key: ref!.documentID)
                print("Document added with ID: \(ref!.documentID)")
            }
            self.view.hideLoadingIndicator()
        }
    }
    
    func updateDocumentKey(key:String){
        db.collection("users").document(key).updateData(["docId":key]) { err in
            if let err = err {
                
            }else {
                debugPrint("successfully saved the data")
            }
            self.view.hideLoadingIndicator()
        }
    }
    
}

extension SignUpVC : UIImagePickerControllerDelegate  {
    func openCamera()
        {
            if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
            {
                imagePicker.sourceType = UIImagePickerController.SourceType.camera
                imagePicker.allowsEditing = true
                imagePicker.delegate = self
                self.present(imagePicker, animated: true, completion: nil)
            }
            else
            {
                let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }

        func openGallary()
        {
            imagePicker.sourceType = UIImagePickerController.SourceType.photoLibrary
            imagePicker.allowsEditing = true
            imagePicker.delegate = self
            self.present(imagePicker, animated: true, completion: nil)
        }
    
    
    
    func presentCameraSettings() {
        let alertController = UIAlertController(title: "Error",
                                      message: "Camera access is denied",
                                      preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Cancel", style: .default))
        alertController.addAction(UIAlertAction(title: "Settings", style: .cancel) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url, options: [:], completionHandler: { success in
                })
            }
        })
        present(alertController, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let editedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage{
            self.imgVwProfilePicture.image = editedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.isNavigationBarHidden = false
        self.dismiss(animated: true, completion: nil)
    }
}
