//
//  TaskDetailVC.swift
//  GymApp
//
//  Created by Chander Dhiman on 16/10/22.
//

import UIKit
import Firebase
class TaskDetailVC: UIViewController {
    
    @IBOutlet weak var lblTask: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnDismissTask: UIButton!
    @IBOutlet weak var btnTaskComplete: UIButton!
    @IBOutlet weak var lblReminderTime: UILabel!
    @IBOutlet weak var txtVwDescription: UITextView!
    @IBOutlet weak var stackVwActionButtons: UIStackView!
    let db = Firestore.firestore() // Database Refernce
    let streakArr = [10,20,30,40,50,60,70,80,90,100] //Streak Array
    var objEvent : EventDates?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblTask.text = objEvent?.goalName ?? ""
        self.lblDate.text = objEvent?.date ?? ""
        self.lblTime.text = objEvent?.time ?? ""
        self.lblReminderTime.text = objEvent?.reminderTime ?? ""
        self.txtVwDescription.text = objEvent?.description ?? ""
        let status = objEvent?.status
        switch status {
        case 0 :
            self.btnTaskComplete.setTitle("Start task", for: .normal)
        case 1 :
            self.btnTaskComplete.setTitle("Complete Task", for: .normal)
        case 2 :
            self.stackVwActionButtons.removeFromSuperview()
            self.btnTaskComplete.setTitle("Complete Task", for: .normal)
        default :
            self.btnTaskComplete.setTitle("Start task", for: .normal)
        }
    }
    
    @IBAction func actionBtnTaskComplete(_ sender: Any) {
        self.view.showLoadingIndicator()
        let id = objEvent?.id ?? ""
        let status = objEvent?.status
        var currentStatus = Int()
        switch status {
        case 0:
            currentStatus = 1
            self.btnTaskComplete.setTitle("Complete Task", for: .normal)
        case 1:
            currentStatus = 2
            self.stackVwActionButtons.removeFromSuperview()
        case 2:
            currentStatus = 2
        default:
            currentStatus = 0
        }
        
        db.collection("events").document(id).updateData(["status":currentStatus]) { err in
            if let err = err {
                debugPrint("err",err.localizedDescription)
            }else {
                if currentStatus == 2 {
                    var currentStreak = UserStoreSingleton.shared.streak ?? 0 //current streak
                   // var currentStreak = 19
                    let newStreak = currentStreak + 1
                    self.updateStreak(streak:newStreak)
                }
            }
            self.view.hideLoadingIndicator()
        }
    }
    
  //MARK: - Update Streak
    func updateStreak(streak:Int){
        //This quary has to be removed because we have
        let userID = Auth.auth().currentUser?.uid ?? ""
        let eventsRef = db.collection("users")
        let query = eventsRef.whereField("uid", isEqualTo: userID).getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    let docId = document.documentID
                    let lastUpdatedDate = document["lastUpdatedStreak"] as? String ?? ""
                    //Pass your current date here statically for changes
                    // Other wise paas the current date using dateformatter
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "dd-MM-yyyy"
                    let date = dateFormatter.string(from: Date())
                    let events = self.db.collection("events").whereField("date", isEqualTo:date).getDocuments { querySnapshot, err in
                        if let err = err {
                            debugPrint("error is occured here")
                        }else {
                            var canAdd = true
                            if querySnapshot?.count == 0 || querySnapshot == nil {
                                self.updateCount(docID: docId, streak: streak,currentDate: date)
                                canAdd = true
                            }else {
                                for event in querySnapshot!.documents {
                                    if (event["status"] as? Int ?? 0) != 2 {
                                        canAdd = false
                                    }
                                }
                            }
                            
                            if canAdd == true {
                                if date != lastUpdatedDate {
                                    self.updateCount(docID: docId, streak: streak,currentDate: date)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    //MARK: - Update Count
    func updateCount(docID:String,streak:Int,currentDate:String){
        db.collection("users").document(docID).updateData(["streak":streak,"lastUpdatedStreak":currentDate]) { err in
            if let err = err {
                debugPrint("err",err.localizedDescription)
            }else {
                UserStoreSingleton.shared.streak = streak
                if self.streakArr.contains(streak){
                    let imageName = "Level\(streak)"
                    self.showBadge(imageName: imageName)
                }
                debugPrint("streak has been updated successfully")
            }
            self.view.hideLoadingIndicator()
        }
    }
    
    //MARK: - Show Badge
    func showBadge(imageName:String){
        let badgeVC = self.storyboard?.instantiateViewController(withIdentifier: "ShareBadgeVC") as! ShareBadgeVC
        badgeVC.imgStr = imageName
        self.present(badgeVC, animated: true)
    }
    
    @IBAction func actionBtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionBtnDismissTask(_ sender: Any) {
        
    }
    
}
