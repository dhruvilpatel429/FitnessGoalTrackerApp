//
//  LoginVM.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import Foundation
import Firebase
class LoginVM {
    static let shared = LoginVM()
    typealias callback = ((_ status : Bool, _ error : String, _ result : AuthDataResult?) -> Void)
    func onclickAuthUser(email:String,password:String,result: @escaping (callback)) {
        FBDatabase.shared.signInFBUser(email: email, password: password) { (status, error, dataResult) in
            result(status, error, dataResult)
        }
    }
}
