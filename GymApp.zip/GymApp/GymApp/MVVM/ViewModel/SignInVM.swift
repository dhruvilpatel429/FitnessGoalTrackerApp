//
//  SignInVM.swift
//  GymApp
//
//  Created by Chander Dhiman on 02/10/22.
//

import Foundation
import Firebase
class SignInVM {
    static let shared = SignInVM()
    typealias callback = ((_ status : Bool, _ error : String, _ result : AuthDataResult?) -> Void)
    
    func onclickSignUpUser(email:String,password:String,result: @escaping (callback)) {
        
        
        FBDatabase.shared.authFBUser(email: email, password: password) { (status, error, dataResult) in
            result(status, error, dataResult)
        }
    }
}
